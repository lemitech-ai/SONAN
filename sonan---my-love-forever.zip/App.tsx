
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Heart, 
  Moon, 
  Sun, 
  Calendar, 
  Camera, 
  MessageCircle, 
  Gift, 
  Gamepad2, 
  Info, 
  Menu, 
  X,
  Volume2,
  VolumeX
} from 'lucide-react';
import LoadingScreen from './components/LoadingScreen';
import Hero from './components/Hero';
import Home from './components/Home';
import Timeline from './components/Timeline';
import Gallery from './components/Gallery';
import LoveNotes from './components/LoveNotes';
import SurpriseBox from './components/SurpriseBox';
import StatsSection from './components/StatsSection';
import HeartGame from './components/HeartGame';
import AboutUs from './components/AboutUs';
import FloatingHearts from './components/FloatingHearts';
import { AppState, Theme } from './types';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.LOADING);
  const [theme, setTheme] = useState<Theme>('day');
  const [isMuted, setIsMuted] = useState(true);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [secretUnlocked, setSecretUnlocked] = useState(false);
  const [heartClicks, setHeartClicks] = useState(0);

  useEffect(() => {
    // Initial loading simulation
    const timer = setTimeout(() => {
      setAppState(AppState.HERO);
    }, 4500);
    return () => clearTimeout(timer);
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme(prev => prev === 'day' ? 'night' : 'day');
  }, []);

  const handleHeartClick = useCallback(() => {
    setHeartClicks(prev => {
      const newVal = prev + 1;
      if (newVal === 7) setSecretUnlocked(true);
      return newVal;
    });
  }, []);

  const themeClasses = theme === 'day' 
    ? 'bg-rose-50 text-rose-900 selection:bg-rose-200' 
    : 'bg-slate-950 text-slate-100 selection:bg-rose-900/50';

  const sections = [
    { id: 'home', icon: Heart, label: 'Home' },
    { id: 'story', icon: Calendar, label: 'Our Story' },
    { id: 'memories', icon: Camera, label: 'Memories' },
    { id: 'notes', icon: MessageCircle, label: 'Notes' },
    { id: 'surprise', icon: Gift, label: 'Surprise' },
    { id: 'toys', icon: Gamepad2, label: 'Play' },
    { id: 'about', icon: Info, label: 'About Us' },
  ];

  if (appState === AppState.LOADING) {
    return <LoadingScreen />;
  }

  if (appState === AppState.HERO) {
    return <Hero onEnter={() => setAppState(AppState.HOME)} theme={theme} />;
  }

  return (
    <div className={`min-h-screen transition-colors duration-1000 ${themeClasses}`}>
      <FloatingHearts theme={theme} />
      
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 px-6 py-4 flex justify-between items-center backdrop-blur-md bg-opacity-30 ${theme === 'day' ? 'bg-white/30 border-b border-rose-200/20' : 'bg-black/30 border-b border-rose-900/20'}`}>
        <motion.div 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }}
          className="flex items-center gap-2 cursor-pointer"
          onClick={handleHeartClick}
        >
          <Heart className={`w-6 h-6 fill-rose-500 text-rose-500 transition-transform ${heartClicks > 0 ? 'scale-125' : ''}`} />
          <span className="font-serif-elegant font-bold text-xl tracking-widest uppercase">Sonan</span>
        </motion.div>

        <div className="hidden md:flex items-center gap-8">
          {sections.map(section => (
            <a 
              key={section.id} 
              href={`#${section.id}`}
              className="hover:text-rose-500 transition-colors text-sm font-medium uppercase tracking-tighter"
            >
              {section.label}
            </a>
          ))}
        </div>

        <div className="flex items-center gap-4">
          <button onClick={() => setIsMuted(!isMuted)} className="p-2 rounded-full hover:bg-rose-500/10 transition-colors">
            {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          </button>
          <button onClick={toggleTheme} className="p-2 rounded-full hover:bg-rose-500/10 transition-colors">
            {theme === 'day' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
          </button>
          <button onClick={() => setIsMenuOpen(true)} className="md:hidden p-2 rounded-full hover:bg-rose-500/10 transition-colors">
            <Menu className="w-5 h-5" />
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            className={`fixed inset-0 z-[60] p-10 flex flex-col items-center justify-center gap-8 ${theme === 'day' ? 'bg-rose-50' : 'bg-slate-950'}`}
          >
            <button onClick={() => setIsMenuOpen(false)} className="absolute top-6 right-6 p-4">
              <X className="w-8 h-8" />
            </button>
            {sections.map((section, idx) => (
              <motion.a
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                key={section.id}
                href={`#${section.id}`}
                onClick={() => setIsMenuOpen(false)}
                className="text-3xl font-serif-elegant flex items-center gap-4 hover:text-rose-500 transition-colors"
              >
                <section.icon className="w-6 h-6" />
                {section.label}
              </motion.a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <main>
        <div id="home"><Home theme={theme} /></div>
        <div id="story"><Timeline theme={theme} /></div>
        <div id="memories"><Gallery theme={theme} /></div>
        <div id="notes"><LoveNotes theme={theme} /></div>
        <div id="surprise"><SurpriseBox theme={theme} /></div>
        <StatsSection theme={theme} />
        <div id="toys"><HeartGame theme={theme} /></div>
        
        {secretUnlocked && (
          <section className="py-20 bg-rose-500 text-white text-center">
            <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}>
              <Heart className="w-20 h-20 mx-auto fill-current animate-pulse mb-6" />
              <h2 className="text-4xl font-serif-elegant mb-4">You found the Secret</h2>
              <p className="max-w-2xl mx-auto italic px-6">
                "No matter where life takes us... Choose me. I will always choose you."
              </p>
            </motion.div>
          </section>
        )}
        
        <div id="about"><AboutUs theme={theme} /></div>
      </main>

      <footer className={`py-12 border-t text-center ${theme === 'day' ? 'border-rose-200' : 'border-slate-800'}`}>
        <p className="font-romantic text-2xl mb-2">Made with every heartbeat...</p>
        <p className="text-xs uppercase tracking-[0.4em] opacity-60">Only for you</p>
        <h3 className="mt-8 font-serif-elegant text-xl tracking-widest text-rose-500">SONAN — my love forever.</h3>
      </footer>
    </div>
  );
};

export default App;
