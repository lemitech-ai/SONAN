
import React from 'react';
import { motion } from 'framer-motion';
// Fix: Import Heart from lucide-react
import { Heart } from 'lucide-react';
import { Theme } from '../types';

const AboutUs: React.FC<{ theme: Theme }> = ({ theme }) => {
  return (
    <section className="py-24 px-6 max-w-6xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          className="space-y-8"
        >
          <div>
            <h3 className="text-sm font-bold uppercase tracking-[0.4em] text-rose-500 mb-4">About Her</h3>
            <p className="font-serif-elegant text-3xl italic leading-relaxed">
              “You are not just someone I love. You are the place my heart returns to.”
            </p>
          </div>

          <div className="pt-8 border-t border-rose-100">
            <h3 className="text-sm font-bold uppercase tracking-[0.4em] text-rose-500 mb-4">About Me</h3>
            <p className="font-serif-elegant text-xl opacity-70 leading-relaxed">
              I am not perfect… But my love for you is honest, patient, and forever.
            </p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          className={`p-12 rounded-[3rem] text-center border shadow-2xl ${theme === 'day' ? 'bg-white border-rose-100' : 'bg-slate-900 border-slate-800'}`}
        >
          <div className="mb-8 relative inline-block">
             <Heart className="w-16 h-16 text-rose-200 fill-rose-200 absolute -top-4 -left-4 animate-pulse" />
             <Heart className="w-16 h-16 text-rose-500 fill-rose-500 relative z-10" />
          </div>
          <h2 className="font-romantic text-6xl mb-6">Together</h2>
          <p className="font-serif-elegant text-2xl italic mb-10">“We are not a moment. We are a promise.”</p>
          <div className="flex justify-center gap-4 text-xs font-bold uppercase tracking-widest opacity-40">
            <span>Honesty</span>
            <span>•</span>
            <span>Patience</span>
            <span>•</span>
            <span>Forever</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default AboutUs;
