
import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';
import { Theme } from '../types';

const FloatingHearts: React.FC<{ theme: Theme }> = ({ theme }) => {
  const heartCount = 15;
  const hearts = useMemo(() => {
    return Array.from({ length: heartCount }).map((_, i) => ({
      id: i,
      x: Math.random() * 100,
      size: Math.random() * 20 + 10,
      duration: Math.random() * 10 + 15,
      delay: Math.random() * 10,
    }));
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {hearts.map(heart => (
        <motion.div
          key={heart.id}
          initial={{ y: '110vh', opacity: 0 }}
          animate={{ 
            y: '-10vh',
            opacity: [0, 0.3, 0.3, 0],
            x: `${heart.x + (Math.sin(heart.id) * 10)}%`
          }}
          transition={{
            duration: heart.duration,
            repeat: Infinity,
            delay: heart.delay,
            ease: "linear"
          }}
          className="absolute"
          style={{ left: `${heart.x}%` }}
        >
          <Heart 
            className={`fill-current ${theme === 'day' ? 'text-rose-200' : 'text-rose-900'}`} 
            style={{ width: heart.size, height: heart.size }} 
          />
        </motion.div>
      ))}
    </div>
  );
};

export default FloatingHearts;
