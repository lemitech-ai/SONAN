
import React from 'react';
import { motion } from 'framer-motion';
import { Theme } from '../types';

const images = [
  "https://picsum.photos/400/500?random=1",
  "https://picsum.photos/400/500?random=2",
  "https://picsum.photos/400/500?random=3",
  "https://picsum.photos/400/500?random=4",
  "https://picsum.photos/400/500?random=5",
  "https://picsum.photos/400/500?random=6",
];

const Gallery: React.FC<{ theme: Theme }> = ({ theme }) => {
  return (
    <section className="py-24 px-6 overflow-hidden">
      <div className="text-center mb-16">
        <h2 className="font-serif-elegant text-4xl mb-4">Our Memories</h2>
        <p className="italic opacity-70">“Memories are proof that love is real.”</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-12 max-w-7xl mx-auto">
        {images.map((img, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 50, rotate: idx % 2 === 0 ? -3 : 3 }}
            whileInView={{ opacity: 1, y: 0 }}
            whileHover={{ y: -10, rotate: 0, scale: 1.02 }}
            className={`p-4 shadow-xl border ${theme === 'day' ? 'bg-white border-rose-100' : 'bg-slate-900 border-slate-800'}`}
          >
            <div className="aspect-[4/5] overflow-hidden mb-4 relative group">
              <img src={img} alt="Memory" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 bg-rose-500/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <p className="text-white font-romantic text-2xl">I wish I could live inside this moment</p>
              </div>
            </div>
            <p className="text-center font-romantic text-xl pt-2 pb-1 text-rose-500">
              {idx === 0 ? "Today's memory chose you." : "Our heart smiling."}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default Gallery;
