
import React, { useState, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart } from 'lucide-react';
import { Theme } from '../types';

const HeartGame: React.FC<{ theme: Theme }> = ({ theme }) => {
  const [score, setScore] = useState(0);
  const [hearts, setHearts] = useState<{ id: number, x: number }[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);

  const spawnHeart = useCallback(() => {
    const id = Date.now();
    const x = Math.random() * 80 + 10; // 10% to 90%
    setHearts(prev => [...prev, { id, x }]);
    
    // Auto remove heart after 3 seconds if not clicked
    setTimeout(() => {
      setHearts(prev => prev.filter(h => h.id !== id));
    }, 3000);
  }, []);

  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(spawnHeart, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, spawnHeart]);

  const catchHeart = (id: number) => {
    setScore(prev => prev + 1);
    setHearts(prev => prev.filter(h => h.id !== id));
  };

  return (
    <section className="py-24 px-6 text-center">
      <div className="mb-12">
        <h2 className="font-serif-elegant text-4xl mb-4">Heart Catch</h2>
        <p className="italic opacity-70">“Catch them gently… That’s how I hold you.”</p>
      </div>

      <div className={`relative max-w-xl mx-auto h-[400px] rounded-3xl border overflow-hidden ${theme === 'day' ? 'bg-rose-100/50 border-rose-200' : 'bg-slate-900/50 border-slate-800'}`}>
        {!isPlaying ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-8 bg-black/5 backdrop-blur-[2px]">
            <p className="mb-6 font-serif-elegant text-xl">Let's play a little?</p>
            <button 
              onClick={() => setIsPlaying(true)}
              className="px-8 py-3 bg-rose-500 text-white rounded-full font-bold uppercase tracking-widest text-sm"
            >
              Start Game
            </button>
          </div>
        ) : (
          <>
            <div className="absolute top-4 left-6 text-2xl font-serif-elegant">
              Score: {score}
            </div>
            <button 
              onClick={() => { setIsPlaying(false); setHearts([]); }}
              className="absolute top-4 right-6 text-xs uppercase tracking-widest opacity-50 underline"
            >
              Quit
            </button>
            <AnimatePresence>
              {hearts.map(heart => (
                <motion.div
                  key={heart.id}
                  initial={{ y: -50, opacity: 0 }}
                  animate={{ y: 400, opacity: 1 }}
                  exit={{ scale: 0, opacity: 0 }}
                  transition={{ duration: 3, ease: "linear" }}
                  className="absolute cursor-pointer"
                  style={{ left: `${heart.x}%` }}
                  onClick={() => catchHeart(heart.id)}
                >
                  <Heart className="w-10 h-10 fill-rose-400 text-rose-400 drop-shadow-lg" />
                </motion.div>
              ))}
            </AnimatePresence>
          </>
        )}
      </div>

      {score > 0 && isPlaying && (
        <p className="mt-6 font-romantic text-2xl text-rose-500">
          {score >= 10 ? "You know my heart better than anyone." : "We fit. Always did."}
        </p>
      )}
    </section>
  );
};

export default HeartGame;
