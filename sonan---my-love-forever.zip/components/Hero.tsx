
import React from 'react';
import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';
import { Theme } from '../types';

interface HeroProps {
  onEnter: () => void;
  theme: Theme;
}

const Hero: React.FC<HeroProps> = ({ onEnter, theme }) => {
  const subtitle = "SONAN — my love, my forever, my heart.";

  return (
    <div className={`fixed inset-0 flex flex-col items-center justify-center p-6 text-center z-[80] transition-colors duration-1000 ${theme === 'day' ? 'bg-rose-50 text-rose-900' : 'bg-slate-950 text-slate-100'}`}>
      <div className="absolute inset-0 pointer-events-none opacity-20">
        <div className="w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-rose-400 via-transparent to-transparent animate-pulse" />
      </div>

      <motion.h1 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 1.5 }}
        className="font-serif-elegant text-6xl md:text-8xl mb-4 font-light tracking-tighter"
      >
        For My Darling
      </motion.h1>

      <div className="mb-12">
        <p className="font-romantic text-2xl md:text-3xl text-rose-500 inline-block overflow-hidden border-r-2 border-rose-500 whitespace-nowrap animate-typing">
          {subtitle}
        </p>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 3, duration: 2 }}
        className="flex flex-col items-center"
      >
        <p className="text-sm opacity-60 italic mb-8 max-w-xs uppercase tracking-widest leading-loose">
          This is not a website...<br />
          This is how I hold you when I’m not there.
        </p>

        <motion.button
          onClick={onEnter}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="group relative flex items-center gap-3 px-8 py-4 bg-white/20 border border-rose-200 backdrop-blur-sm rounded-full overflow-hidden hover:bg-rose-500 hover:text-white transition-all duration-500"
        >
          <div className="absolute inset-0 bg-rose-500/10 group-hover:bg-rose-500 transition-colors" />
          <Heart className="w-5 h-5 fill-rose-500 group-hover:fill-white text-rose-500 group-hover:text-white transition-all animate-pulse" />
          <span className="relative z-10 font-medium tracking-tight">Open what my heart has been keeping</span>
        </motion.button>
      </motion.div>

      {/* Fixed: Removed 'jsx' attribute as it is not supported in standard React style components without specific plugins */}
      <style>{`
        @keyframes typing {
          from { width: 0 }
          to { width: 100% }
        }
        .animate-typing {
          animation: typing 3s steps(40, end);
        }
      `}</style>
    </div>
  );
};

export default Hero;