
import React from 'react';
import { motion } from 'framer-motion';
import { Theme } from '../types';

const Home: React.FC<{ theme: Theme }> = ({ theme }) => {
  return (
    <section className="min-h-screen flex flex-col items-center justify-center p-6 pt-32 text-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1.5 }}
        className="max-w-4xl"
      >
        <h2 className="font-romantic text-5xl md:text-7xl mb-8">
          {theme === 'day' ? 'Good morning, my sunshine.' : 'Rest now...'}
        </h2>
        <p className="font-serif-elegant text-2xl md:text-4xl mb-12 italic leading-snug">
          “If love had a home… It would look like this.”
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
          {[
            { text: "Every color here was chosen for you.", delay: 0.2 },
            { text: "Every movement breathes your name.", delay: 0.4 },
            { text: "You are forever here.", delay: 0.6 }
          ].map((item, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: item.delay }}
              className={`p-8 rounded-3xl border transition-all hover:scale-105 ${theme === 'day' ? 'bg-white/40 border-rose-100' : 'bg-slate-900/40 border-slate-800'}`}
            >
              <p className="text-lg italic opacity-80">{item.text}</p>
            </motion.div>
          ))}
        </div>

        <motion.p 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="mt-20 text-sm tracking-[0.3em] uppercase opacity-50"
        >
          Scroll to see our world
        </motion.p>
      </motion.div>
    </section>
  );
};

export default Home;
