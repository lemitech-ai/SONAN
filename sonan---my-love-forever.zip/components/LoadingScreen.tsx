
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';

const LoadingScreen: React.FC = () => {
  const [textIndex, setTextIndex] = useState(0);
  const texts = [
    "Some things take time to load...",
    "Because they are worth forever.",
    "Please wait...",
    "A heart is opening."
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setTextIndex(prev => (prev < texts.length - 1 ? prev + 1 : prev));
    }, 1500);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="fixed inset-0 bg-rose-50 flex flex-col items-center justify-center z-[100] p-6">
      <motion.div
        animate={{ 
          scale: [1, 1.2, 1],
          opacity: [0.5, 1, 0.5]
        }}
        transition={{ 
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className="mb-12"
      >
        <Heart className="w-16 h-16 fill-rose-400 text-rose-400" />
      </motion.div>

      <div className="h-12 overflow-hidden text-center relative w-full">
        {texts.map((text, idx) => (
          <motion.p
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            animate={textIndex === idx ? { opacity: 1, y: 0 } : { opacity: 0, y: -20 }}
            transition={{ duration: 0.8 }}
            className="absolute inset-0 font-serif-elegant text-lg md:text-2xl text-rose-700 italic"
          >
            {text}
          </motion.p>
        ))}
      </div>

      <div className="mt-20 w-48 h-1 bg-rose-100 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: "100%" }}
          transition={{ duration: 4.5, ease: "linear" }}
          className="h-full bg-rose-400"
        />
      </div>
    </div>
  );
};

export default LoadingScreen;
