
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart } from 'lucide-react';
import { Theme } from '../types';

const notes = [
  "If loving you is a habit, I never want to quit.",
  "You are my favorite thought.",
  "Even silence feels warm when it’s with you.",
  "Every song reminds me of your smile.",
  "My heart beat faster when you message.",
  "You are my safe haven."
];

const LoveNotes: React.FC<{ theme: Theme }> = ({ theme }) => {
  const [activeNote, setActiveNote] = useState<number | null>(null);
  const [kissAnimation, setKissAnimation] = useState(false);

  const sendKiss = () => {
    setKissAnimation(true);
    setTimeout(() => setKissAnimation(false), 2000);
  };

  return (
    <section className="py-24 px-6 bg-rose-500/5 relative overflow-hidden">
      <div className="text-center mb-16">
        <h2 className="font-serif-elegant text-4xl mb-4">Love Notes</h2>
        <p className="italic max-w-md mx-auto opacity-70">“Some words are too soft for the world… So I kept them here, just for you.”</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-6 max-w-4xl mx-auto relative h-[400px]">
        {notes.map((note, idx) => (
          <motion.div
            key={idx}
            drag
            dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
            initial={{ rotate: Math.random() * 20 - 10 }}
            whileHover={{ scale: 1.1, zIndex: 10, rotate: 0 }}
            onClick={() => setActiveNote(idx)}
            className={`cursor-pointer p-6 aspect-square flex items-center justify-center text-center shadow-lg transform transition-colors ${theme === 'day' ? 'bg-white text-rose-900 border-rose-100' : 'bg-slate-900 text-slate-100 border-slate-800'}`}
            style={{ borderRadius: '15% 5% 20% 10% / 10% 20% 5% 15%' }}
          >
            <p className="font-romantic text-xl leading-relaxed">{note}</p>
          </motion.div>
        ))}
      </div>

      <div className="mt-20 text-center">
        <button 
          onClick={sendKiss}
          className="group relative inline-flex items-center gap-2 px-10 py-4 bg-rose-500 text-white rounded-full font-bold overflow-hidden transition-all hover:pr-14"
        >
          <span className="relative z-10 uppercase tracking-widest text-sm">Send you a kiss from my heart</span>
          <span className="absolute right-6 opacity-0 group-hover:opacity-100 transition-opacity">💋</span>
        </button>
      </div>

      <AnimatePresence>
        {kissAnimation && (
          <motion.div
            initial={{ opacity: 0, scale: 0.5, y: 100 }}
            animate={{ opacity: 1, scale: 2, y: -400 }}
            exit={{ opacity: 0, scale: 4 }}
            className="fixed inset-0 pointer-events-none flex items-center justify-center z-[100]"
          >
            <div className="relative">
              <span className="text-9xl">💋</span>
              {[...Array(8)].map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1, x: Math.cos(i) * 200, y: Math.sin(i) * 200, opacity: 0 }}
                  transition={{ duration: 1.5 }}
                  className="absolute top-1/2 left-1/2"
                >
                  <Heart className="w-8 h-8 fill-rose-500 text-rose-500" />
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};

export default LoveNotes;
