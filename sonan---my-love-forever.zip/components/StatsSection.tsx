
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Theme } from '../types';

const StatsSection: React.FC<{ theme: Theme }> = ({ theme }) => {
  const [days, setDays] = useState(0);

  useEffect(() => {
    // Arbitrary start date - replace with real one if needed
    const startDate = new Date('2023-01-01');
    const interval = setInterval(() => {
      const now = new Date();
      const diff = Math.floor((now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
      setDays(diff);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="py-24 px-6 border-y border-rose-100 overflow-hidden bg-white/10 backdrop-blur-sm">
      <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center justify-around gap-12">
        <div className="text-center">
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            className="text-6xl md:text-8xl font-serif-elegant text-rose-500 mb-2"
          >
            {days}
          </motion.div>
          <p className="uppercase tracking-[0.3em] text-xs opacity-60">Days since I met you</p>
          <p className="font-romantic text-xl mt-2 italic">“Not enough.”</p>
        </div>

        <div className="w-px h-20 bg-rose-200 hidden md:block" />

        <div className="text-center">
          <motion.div
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ repeat: Infinity, duration: 3 }}
            className="text-6xl md:text-8xl font-serif-elegant text-rose-500 mb-2"
          >
            ∞
          </motion.div>
          <p className="uppercase tracking-[0.3em] text-xs opacity-60">Days until forever</p>
          <p className="font-romantic text-xl mt-2 italic">“Already started.”</p>
        </div>
      </div>

      <div className="mt-20 text-center">
        <p className="font-serif-elegant text-2xl italic leading-relaxed max-w-lg mx-auto">
          “If time asks me where I’m going… I’ll say: to you.”
        </p>
      </div>
    </section>
  );
};

export default StatsSection;
