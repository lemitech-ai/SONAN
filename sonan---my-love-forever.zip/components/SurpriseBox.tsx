
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Gift, Heart } from 'lucide-react';
import { Theme } from '../types';

const surpriseMessages = [
  "Open when you feel sad — remember, you are never alone.",
  "Open when you miss me — I’m closer than you think.",
  "Open when you smile — because that smile is my favorite place."
];

const SurpriseBox: React.FC<{ theme: Theme }> = ({ theme }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [msgIdx, setMsgIdx] = useState(0);

  const handleOpen = () => {
    if (!isOpen) {
      setIsOpen(true);
      setMsgIdx(Math.floor(Math.random() * surpriseMessages.length));
    } else {
      setIsOpen(false);
    }
  };

  return (
    <section className="py-24 px-6 flex flex-col items-center">
      <div className="text-center mb-16">
        <h2 className="font-serif-elegant text-4xl mb-4">Surprise Box</h2>
        <p className="italic opacity-70">“Not all surprises are loud… Some are gentle, like love.”</p>
      </div>

      <div className="relative w-64 h-64 cursor-pointer" onClick={handleOpen}>
        <motion.div
          animate={isOpen ? { rotateY: 180, scale: 1.1 } : { rotateY: 0, scale: 1 }}
          transition={{ type: "spring", stiffness: 100 }}
          className="w-full h-full relative"
          style={{ transformStyle: 'preserve-3d' }}
        >
          {/* Box Cover */}
          <motion.div 
            className="absolute inset-0 bg-rose-600 rounded-xl flex items-center justify-center border-4 border-rose-400 z-10 shadow-2xl"
            animate={isOpen ? { y: -150, rotateX: -90, opacity: 0 } : { y: 0, opacity: 1 }}
          >
            <div className="w-10 h-full bg-rose-400 absolute left-1/2 -translate-x-1/2" />
            <div className="h-10 w-full bg-rose-400 absolute top-1/2 -translate-y-1/2" />
            <Gift className="w-20 h-20 text-white relative z-20" />
          </motion.div>

          {/* Box Bottom */}
          <div className="absolute inset-0 bg-rose-700 rounded-xl border-4 border-rose-500 flex items-center justify-center">
             <Heart className="w-16 h-16 fill-rose-400 text-rose-400 opacity-50" />
          </div>
        </motion.div>

        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, y: 50, scale: 0.5 }}
              animate={{ opacity: 1, y: -120, scale: 1 }}
              exit={{ opacity: 0, y: 50, scale: 0.5 }}
              className={`absolute left-1/2 -translate-x-1/2 p-8 rounded-3xl border-2 shadow-2xl min-w-[300px] text-center ${theme === 'day' ? 'bg-white border-rose-200' : 'bg-slate-900 border-rose-900'}`}
            >
              <h3 className="font-romantic text-3xl mb-4 text-rose-500">For You</h3>
              <p className="font-serif-elegant text-xl leading-relaxed">
                {surpriseMessages[msgIdx]}
              </p>
              <button 
                onClick={(e) => { e.stopPropagation(); setIsOpen(false); }}
                className="mt-6 text-xs uppercase tracking-widest opacity-50 hover:opacity-100 underline"
              >
                Close it for now
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <p className="mt-12 text-sm italic opacity-50">
        {isOpen ? "“This is where I hide the things I don’t always know how to say.”" : "Tap the ribbon to peek inside..."}
      </p>
    </section>
  );
};

export default SurpriseBox;
