
import React from 'react';
import { motion } from 'framer-motion';
import { Theme } from '../types';

const events = [
  {
    date: "The Day We Met",
    content: "On this day, I didn’t just smile… I started believing in forever.",
    side: 'left'
  },
  {
    date: "Our First Whisper",
    content: "Some moments change time itself. You were one of them.",
    side: 'right'
  },
  {
    date: "Today",
    content: "This story is still being written… And every page has your name.",
    side: 'left'
  }
];

const Timeline: React.FC<{ theme: Theme }> = ({ theme }) => {
  return (
    <section className="py-24 px-6 max-w-5xl mx-auto">
      <div className="text-center mb-20">
        <h2 className="font-serif-elegant text-4xl mb-4">Our Story</h2>
        <p className="font-romantic text-2xl text-rose-500 italic">“Every love has a beginning… Ours became a destiny.”</p>
      </div>

      <div className="relative">
        <div className={`absolute left-1/2 -translate-x-1/2 top-0 bottom-0 w-px ${theme === 'day' ? 'bg-rose-200' : 'bg-slate-800'}`} />
        
        <div className="space-y-24">
          {events.map((event, idx) => (
            <div key={idx} className={`flex items-center w-full ${event.side === 'left' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className="w-1/2 px-8">
                <motion.div
                  initial={{ opacity: 0, x: event.side === 'left' ? 30 : -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ margin: "-100px" }}
                  className={`p-8 rounded-2xl border transition-all ${theme === 'day' ? 'bg-white border-rose-100' : 'bg-slate-900 border-slate-800'}`}
                >
                  <span className="text-xs font-bold uppercase tracking-widest text-rose-500 block mb-2">{event.date}</span>
                  <p className="font-serif-elegant text-xl italic leading-relaxed">{event.content}</p>
                </motion.div>
              </div>
              <div className="relative z-10 w-4 h-4 rounded-full bg-rose-500 border-4 border-rose-50 shadow-xl" />
              <div className="w-1/2" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Timeline;
