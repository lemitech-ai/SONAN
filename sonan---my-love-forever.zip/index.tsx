
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import ReactDOM from 'react-dom/client';
import { motion, AnimatePresence, useScroll, useTransform } from 'framer-motion';
import { 
  Heart, Moon, Sun, Calendar, Camera, MessageCircle, Gift, 
  Gamepad2, Info, Menu, X, Volume2, VolumeX, Sparkles, 
  Send, Lock, CheckCircle2, Trophy, RotateCcw
} from 'lucide-react';

// --- Types ---
type Theme = 'day' | 'night';
type Screen = 'loading' | 'hero' | 'home';

// --- Components ---

const LoadingScreen: React.FC = () => {
  const [textIndex, setTextIndex] = useState(0);
  const texts = [
    "Some things take time to load...",
    "Because they are worth forever.",
    "Please wait...",
    "A heart is opening."
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setTextIndex(prev => (prev < texts.length - 1 ? prev + 1 : prev));
    }, 1200);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="fixed inset-0 bg-rose-50 flex flex-col items-center justify-center z-[100] p-6">
      <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 2, repeat: Infinity }} className="mb-12">
        <Heart className="w-20 h-20 fill-rose-400 text-rose-400 heart-pulse" />
      </motion.div>
      <div className="h-12 overflow-hidden text-center relative w-full">
        {texts.map((text, idx) => (
          <motion.p
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            animate={textIndex === idx ? { opacity: 1, y: 0 } : { opacity: 0, y: -20 }}
            className="absolute inset-0 font-serif-elegant text-xl md:text-3xl text-rose-700 italic"
          >
            {text}
          </motion.p>
        ))}
      </div>
    </div>
  );
};

const LoveQuiz: React.FC<{ theme: Theme }> = ({ theme }) => {
  const [step, setStep] = useState(0);
  const [score, setScore] = useState(0);
  const questions = [
    { q: "Where does my heart go when it's cold?", a: "To you", options: ["The beach", "To you", "To sleep"] },
    { q: "What is my favorite sound in the world?", a: "Your laugh", options: ["Music", "Silence", "Your laugh"] },
    { q: "How long is 'forever' for us?", a: "Just the beginning", options: ["100 years", "Just the beginning", "Until tomorrow"] }
  ];

  const handleAnswer = (opt: string) => {
    if (opt === questions[step].a) setScore(s => s + 1);
    if (step < questions.length - 1) setStep(s => s + 1);
    else setStep(-1); // Finished
  };

  return (
    <div className={`p-8 rounded-3xl border-2 ${theme === 'day' ? 'bg-white border-rose-100' : 'bg-slate-900 border-slate-800'} max-w-lg mx-auto`}>
      <h3 className="font-serif-elegant text-2xl mb-6">Love Quiz</h3>
      {step >= 0 ? (
        <div>
          <p className="mb-6 italic text-lg">"{questions[step].q}"</p>
          <div className="space-y-3">
            {questions[step].options.map(opt => (
              <button key={opt} onClick={() => handleAnswer(opt)} className="w-full py-3 rounded-xl border border-rose-200 hover:bg-rose-500 hover:text-white transition-all">
                {opt}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="text-center">
          <Trophy className="w-12 h-12 text-rose-500 mx-auto mb-4" />
          <p className="font-romantic text-3xl mb-2">You scored {score}/{questions.length}!</p>
          <p className="opacity-70">You know my heart better than anyone.</p>
          <button onClick={() => {setStep(0); setScore(0);}} className="mt-4 text-rose-500 underline flex items-center justify-center gap-2 mx-auto">
            <RotateCcw className="w-4 h-4" /> Try again
          </button>
        </div>
      )}
    </div>
  );
};

const MemoryMatch: React.FC<{ theme: Theme }> = ({ theme }) => {
  const symbols = ['❤️', '💍', '🌸', '🕊️', '🧸', '💌'];
  const [cards, setCards] = useState(() => [...symbols, ...symbols].sort(() => Math.random() - 0.5).map((s, i) => ({ id: i, s, flipped: false, matched: false })));
  const [flipped, setFlipped] = useState<number[]>([]);

  const handleFlip = (id: number) => {
    if (flipped.length === 2 || cards[id].flipped || cards[id].matched) return;
    const newCards = [...cards];
    newCards[id].flipped = true;
    setCards(newCards);
    setFlipped(f => [...f, id]);
  };

  useEffect(() => {
    if (flipped.length === 2) {
      const [id1, id2] = flipped;
      if (cards[id1].s === cards[id2].s) {
        const newCards = [...cards];
        newCards[id1].matched = true;
        newCards[id2].matched = true;
        setCards(newCards);
        setFlipped([]);
      } else {
        setTimeout(() => {
          const newCards = [...cards];
          newCards[id1].flipped = false;
          newCards[id2].flipped = false;
          setCards(newCards);
          setFlipped([]);
        }, 1000);
      }
    }
  }, [flipped, cards]);

  return (
    <div className="max-w-md mx-auto">
      <div className="grid grid-cols-4 gap-3">
        {cards.map(card => (
          <div key={card.id} onClick={() => handleFlip(card.id)} className={`aspect-square cursor-pointer transition-all duration-500 transform-gpu relative ${card.flipped || card.matched ? 'rotate-y-180' : ''}`}>
            <div className={`absolute inset-0 rounded-xl flex items-center justify-center text-2xl shadow-md border ${card.flipped || card.matched ? 'bg-rose-100 border-rose-300' : 'bg-rose-500 text-white'}`}>
              {(card.flipped || card.matched) ? card.s : '?'}
            </div>
          </div>
        ))}
      </div>
      <button onClick={() => setCards([...symbols, ...symbols].sort(() => Math.random() - 0.5).map((s, i) => ({ id: i, s, flipped: false, matched: false })))} className="mt-6 opacity-50 hover:opacity-100 transition-opacity">Reset Match</button>
    </div>
  );
};

const Hero: React.FC<{ onEnter: () => void; theme: Theme }> = ({ onEnter, theme }) => {
  return (
    <div className={`fixed inset-0 flex flex-col items-center justify-center p-6 text-center z-[80] transition-colors duration-1000 ${theme === 'day' ? 'bg-rose-50 text-rose-900' : 'bg-slate-950 text-slate-100'}`}>
      <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 1.5 }}>
        <h1 className="font-serif-elegant text-5xl md:text-9xl mb-4 font-light tracking-tighter">For My Darling</h1>
        <p className="font-romantic text-3xl md:text-5xl text-rose-500 mb-12">SONAN — my love, my forever, my heart.</p>
        <p className="text-sm opacity-60 italic mb-8 max-w-sm mx-auto uppercase tracking-widest leading-loose">
          This is not a website... This is how I hold you when I’m not there.
        </p>
        <motion.button
          onClick={onEnter}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="group relative flex items-center gap-3 px-12 py-5 bg-white text-rose-900 rounded-full shadow-2xl overflow-hidden hover:bg-rose-500 hover:text-white transition-all duration-500"
        >
          <Heart className="w-5 h-5 fill-rose-500 group-hover:fill-white text-rose-500 group-hover:text-white animate-pulse" />
          <span className="relative z-10 font-bold tracking-tight">Open my heart</span>
        </motion.button>
      </motion.div>
    </div>
  );
};

const SurpriseBox: React.FC<{ theme: Theme }> = ({ theme }) => {
  const [isOpen, setIsOpen] = useState(false);
  const messages = [
    "Open when you feel sad — remember, you are never alone.",
    "Open when you miss me — I’m closer than you think.",
    "Open when you smile — because that smile is my favorite place."
  ];

  return (
    <div className="flex flex-col items-center py-20">
      <motion.div 
        animate={isOpen ? { scale: 1.1 } : { scale: 1 }} 
        className="relative w-48 h-48 cursor-pointer" 
        onClick={() => setIsOpen(!isOpen)}
      >
        <motion.div 
          animate={isOpen ? { y: -100, rotate: 15, opacity: 0 } : { y: 0, opacity: 1 }}
          className="absolute inset-0 bg-rose-600 rounded-2xl z-20 border-4 border-rose-400 flex items-center justify-center shadow-xl"
        >
          <div className="w-6 h-full bg-rose-400 absolute left-1/2 -translate-x-1/2" />
          <div className="h-6 w-full bg-rose-400 absolute top-1/2 -translate-y-1/2" />
          <Gift className="text-white w-12 h-12 relative z-30" />
        </motion.div>
        <div className="absolute inset-0 bg-rose-800 rounded-2xl flex items-center justify-center text-white p-4 text-center">
          <p className="font-serif-elegant italic">{messages[Math.floor(Date.now()/1000000)%3]}</p>
        </div>
      </motion.div>
      <p className="mt-8 italic opacity-50">{isOpen ? "I hide these things for you." : "Tap to open the ribbon..."}</p>
    </div>
  );
};

const App: React.FC = () => {
  const [appState, setAppState] = useState<Screen>('loading');
  const [theme, setTheme] = useState<Theme>('day');
  const [isMuted, setIsMuted] = useState(true);
  const [secretUnlocked, setSecretUnlocked] = useState(false);
  const [heartClicks, setHeartClicks] = useState(0);
  const [kisses, setKisses] = useState<{ id: number, x: number, y: number }[]>([]);

  useEffect(() => {
    setTimeout(() => setAppState('hero'), 4000);
  }, []);

  const sendKiss = (e: React.MouseEvent) => {
    const id = Date.now();
    setKisses(prev => [...prev, { id, x: e.clientX, y: e.clientY }]);
    setTimeout(() => setKisses(prev => prev.filter(k => k.id !== id)), 2000);
  };

  const onSecretClick = () => {
    setHeartClicks(c => {
      if (c + 1 >= 7) setSecretUnlocked(true);
      return c + 1;
    });
  };

  const themeClass = theme === 'day' ? 'bg-rose-50 text-rose-900' : 'bg-slate-950 text-slate-100';

  if (appState === 'loading') return <LoadingScreen />;
  if (appState === 'hero') return <Hero onEnter={() => setAppState('home')} theme={theme} />;

  return (
    <div className={`min-h-screen transition-colors duration-1000 ${themeClass}`} onClick={sendKiss}>
      {/* Kisses Animation */}
      <AnimatePresence>
        {kisses.map(k => (
          <motion.div key={k.id} initial={{ scale: 0, opacity: 1 }} animate={{ scale: 4, opacity: 0, y: -200 }} className="fixed pointer-events-none text-4xl z-[99]" style={{ left: k.x - 20, top: k.y - 20 }}>💋</motion.div>
        ))}
      </AnimatePresence>

      {/* Nav */}
      <nav className={`fixed top-0 inset-x-0 z-50 px-6 py-4 flex justify-between items-center backdrop-blur-lg ${theme === 'day' ? 'bg-white/40' : 'bg-black/40'}`}>
        <div className="flex items-center gap-2 cursor-pointer" onClick={onSecretClick}>
          <Heart className={`w-6 h-6 fill-rose-500 text-rose-500 ${heartClicks > 0 ? 'scale-125' : ''}`} />
          <span className="font-serif-elegant font-bold text-xl uppercase tracking-tighter">Sonan</span>
        </div>
        <div className="flex items-center gap-4">
          <button onClick={() => setIsMuted(!isMuted)} className="p-2">{isMuted ? <VolumeX /> : <Volume2 />}</button>
          <button onClick={() => setTheme(theme === 'day' ? 'night' : 'day')} className="p-2">{theme === 'day' ? <Moon /> : <Sun />}</button>
        </div>
      </nav>

      {/* Home Content */}
      <main className="max-w-6xl mx-auto px-6 pt-32 pb-24 space-y-32">
        <section className="text-center">
          <motion.h2 initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} className="font-romantic text-6xl md:text-8xl mb-8">
            {theme === 'day' ? 'Good morning, my sunshine.' : 'Rest now, my love.'}
          </motion.h2>
          <p className="font-serif-elegant text-2xl md:text-4xl italic opacity-80 leading-relaxed">
            “If love had a home… It would look like this.”
          </p>
        </section>

        <section id="story" className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text- rose-500 uppercase tracking-widest text-xs font-bold mb-4">Our Story</h3>
            <p className="font-serif-elegant text-3xl mb-6 leading-relaxed italic">“Every love has a beginning… Ours became a destiny.”</p>
            <div className="space-y-8 pl-4 border-l-2 border-rose-200">
              <div className="relative">
                <div className="absolute -left-[21px] top-1 w-4 h-4 rounded-full bg-rose-500" />
                <p className="font-bold">The Start</p>
                <p className="opacity-70">On this day, I didn’t just smile… I started believing in forever.</p>
              </div>
              <div className="relative">
                <div className="absolute -left-[21px] top-1 w-4 h-4 rounded-full bg-rose-500" />
                <p className="font-bold">The Middle</p>
                <p className="opacity-70">Some moments change time itself. You were one of them.</p>
              </div>
              <div className="relative">
                <div className="absolute -left-[21px] top-1 w-4 h-4 rounded-full bg-rose-500" />
                <p className="font-bold">Always</p>
                <p className="opacity-70">This story is still being written… and every page has your name.</p>
              </div>
            </div>
          </div>
          <div className="relative aspect-square rounded-[4rem] overflow-hidden shadow-2xl">
            <img src="https://images.unsplash.com/photo-1518199266791-5375a83190b7?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-rose-500/20 mix-blend-overlay" />
          </div>
        </section>

        <section id="notes">
          <div className="text-center mb-12">
            <h2 className="font-serif-elegant text-4xl mb-4">Love Notes</h2>
            <p className="italic opacity-60">“Some words are too soft for the world… So I kept them here, just for you.”</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
            {["If loving you is a habit, I never want to quit.", "You are my favorite thought.", "Even silence feels warm when it's with you."].map((note, i) => (
              <motion.div whileHover={{ scale: 1.05, rotate: 0 }} initial={{ rotate: i % 2 === 0 ? -3 : 3 }} key={i} className={`p-8 aspect-square flex items-center justify-center text-center rounded-3xl shadow-lg border-2 ${theme === 'day' ? 'bg-white border-rose-50' : 'bg-slate-900 border-slate-800'}`}>
                <p className="font-romantic text-2xl leading-snug">{note}</p>
              </motion.div>
            ))}
          </div>
        </section>

        <section id="toys" className="grid md:grid-cols-2 gap-12">
          <LoveQuiz theme={theme} />
          <MemoryMatch theme={theme} />
        </section>

        <SurpriseBox theme={theme} />

        <section id="about" className="text-center py-20 border-t border-rose-100">
          <h2 className="font-romantic text-6xl mb-12">About Us</h2>
          <div className="grid md:grid-cols-2 gap-20">
            <div className="space-y-4">
              <h4 className="uppercase tracking-widest text-xs font-bold text-rose-500">About Her</h4>
              <p className="font-serif-elegant text-2xl italic leading-relaxed">“You are not just someone I love. You are the place my heart returns to.”</p>
            </div>
            <div className="space-y-4">
              <h4 className="uppercase tracking-widest text-xs font-bold text-rose-500">About Me</h4>
              <p className="opacity-70 leading-relaxed italic">I am not perfect… But my love for you is honest, patient, and forever.</p>
            </div>
          </div>
          <div className="mt-20">
            <p className="font-serif-elegant text-4xl">“We are not a moment. We are a promise.”</p>
          </div>
        </section>
      </main>

      {secretUnlocked && (
        <div className="fixed inset-0 z-[100] bg-rose-600 flex flex-col items-center justify-center text-white p-6 text-center">
          <button onClick={() => setSecretUnlocked(false)} className="absolute top-10 right-10"><X /></button>
          <Heart className="w-24 h-24 mb-8 fill-white heart-pulse" />
          <h2 className="font-serif-elegant text-5xl mb-6 italic">If you found this...</h2>
          <p className="text-2xl max-w-lg mx-auto italic font-romantic">“No matter where life takes us… Choose me. I will always choose you.”</p>
        </div>
      )}

      <footer className="py-20 border-t border-rose-100 text-center opacity-60">
        <p className="font-romantic text-2xl mb-4">Made with every heartbeat...</p>
        <h3 className="font-serif-elegant text-xl tracking-[0.3em]">SONAN — MY LOVE FOREVER</h3>
      </footer>
    </div>
  );
};

const rootElement = document.getElementById('root');
if (rootElement) {
  const root = ReactDOM.createRoot(rootElement);
  root.render(<App />);
}
