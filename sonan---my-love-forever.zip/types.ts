
// Types for better consolidation across the app.

export enum AppState {
  LOADING = 'LOADING',
  HERO = 'HERO',
  HOME = 'HOME'
}

export type Theme = 'day' | 'night';
